// frontend/src/pages/ProviderTypeSelection.jsx
import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { FaHome, FaUserTie, FaHardHat, FaArrowRight, FaArrowLeft, FaClock } from 'react-icons/fa';

const ProviderTypeSelection = () => {
  const [selectedType, setSelectedType] = useState('');
  const navigate = useNavigate();

  const providerTypes = [
    {
      type: 'owner',
      title: 'Property Owner',
      icon: FaHome,
      description: 'I own property I want to sell or rent',
      color: 'purple',
      gradient: 'from-purple-500 to-pink-600',
      features: [
        'Post your own properties',
        'Instant approval - no waiting',
        'Full control over listings',
        'Direct communication with buyers'
      ],
      approvalNeeded: false
    },
    {
      type: 'agent',
      title: 'Real Estate Agent',
      icon: FaUserTie,
      description: 'Professional agent representing clients',
      color: 'orange',
      gradient: 'from-orange-500 to-red-600',
      features: [
        'Post unlimited properties',
        'Verified agent badge',
        'Advanced analytics dashboard',
        'Priority support'
      ],
      approvalNeeded: true
    },
    {
      type: 'builder',
      title: 'Builder/Developer',
      icon: FaHardHat,
      description: 'Construction company or developer',
      color: 'red',
      gradient: 'from-red-500 to-rose-600',
      features: [
        'Post entire projects',
        'Bulk property upload',
        'Verified builder badge',
        'Project showcase pages'
      ],
      approvalNeeded: true
    }
  ];

  const handleContinue = () => {
    if (!selectedType) return;
    navigate(`/signup/provider/${selectedType}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Back Button */}
        <button
          onClick={() => navigate('/signup/role-selection')}
          className="flex items-center text-gray-600 hover:text-gray-900 mb-8 transition-colors"
        >
          <FaArrowLeft className="mr-2" />
          Back to role selection
        </button>

        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            What type of <span className="text-green-600">provider</span> are you?
          </h1>
          <p className="text-xl text-gray-600">
            Choose the option that best describes you
          </p>
        </div>

        {/* Provider Type Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {providerTypes.map((provider) => {
            const Icon = provider.icon;
            const isSelected = selectedType === provider.type;
            
            return (
              <div
                key={provider.type}
                onClick={() => setSelectedType(provider.type)}
                className={`relative bg-white rounded-2xl shadow-xl p-6 cursor-pointer transition-all duration-300 hover:shadow-2xl ${
                  isSelected 
                    ? 'ring-4 ring-offset-4 ring-' + provider.color + '-500 transform scale-105' 
                    : 'hover:scale-102'
                }`}
              >
                {/* Selected Badge */}
                {isSelected && (
                  <div className="absolute -top-3 -right-3">
                    <div className={`bg-gradient-to-r ${provider.gradient} text-white px-3 py-1 rounded-full shadow-lg text-sm font-semibold`}>
                      ✓ Selected
                    </div>
                  </div>
                )}

                {/* Approval Badge */}
                {provider.approvalNeeded && (
                  <div className="absolute -top-3 -left-3">
                    <div className="bg-yellow-500 text-white px-3 py-1 rounded-full shadow-lg text-xs font-semibold flex items-center">
                      <FaClock className="mr-1" />
                      Approval Needed
                    </div>
                  </div>
                )}

                {/* Icon */}
                <div className={`w-16 h-16 bg-gradient-to-r ${provider.gradient} rounded-xl flex items-center justify-center mb-4 mx-auto shadow-lg`}>
                  <Icon className="text-3xl text-white" />
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-gray-900 text-center mb-2">
                  {provider.title}
                </h3>
                
                {/* Description */}
                <p className="text-gray-600 text-center text-sm mb-4">
                  {provider.description}
                </p>

                {/* Features */}
                <ul className="space-y-2">
                  {provider.features.map((feature, index) => (
                    <li key={index} className="flex items-start text-sm">
                      <svg className="w-5 h-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        {/* Continue Button */}
        <div className="text-center">
          <button
            onClick={handleContinue}
            disabled={!selectedType}
            className={`inline-flex items-center px-10 py-4 rounded-xl text-lg font-bold transition-all transform ${
              selectedType
                ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white hover:from-green-700 hover:to-emerald-700 shadow-xl hover:shadow-2xl hover:scale-105'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Continue to Signup
            <FaArrowRight className="ml-3" />
          </button>
        </div>

        {/* Info Box */}
        <div className="mt-12 bg-yellow-50 border border-yellow-200 rounded-xl p-6">
          <div className="flex items-start">
            <FaClock className="text-yellow-600 text-2xl mr-4 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-bold text-yellow-900 mb-2">Approval Process</h3>
              <ul className="text-sm text-yellow-800 space-y-2">
                <li><strong>Property Owner:</strong> Instant approval - start posting immediately</li>
                <li><strong>Agent:</strong> Admin reviews your credentials (usually within 24-48 hours)</li>
                <li><strong>Builder:</strong> Admin verifies company details (usually within 24-48 hours)</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProviderTypeSelection;